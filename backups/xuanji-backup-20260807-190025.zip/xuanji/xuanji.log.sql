-- H2 2.4.240;
;             
CREATE USER IF NOT EXISTS "SA" SALT '1545d7e899c6eb15' HASH 'b9d9fb315d6a02efd9d18d51adb651916e6d57fa60bd3d7a9e47b6becd9bd54e' ADMIN;         
